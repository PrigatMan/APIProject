﻿namespace APIProject.Model
{
    public class Persoana
    {
        public int Id { get; set; } = 0;
        public string Nume { get; set; } = "";
        public string Prenume { get; set; } = "";
        public string Adresa { get; set; } = "";
        public string Email { get; set; } = "";
    }
}
