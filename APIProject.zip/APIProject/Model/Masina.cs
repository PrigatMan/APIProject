﻿namespace APIProject.Model
{
    public class Masina
    {
        public int Id { get; set; } = 0;
        public string Marca { get; set; } = "";
        public string Model { get; set; } = "";
        public int An { get; set; } = 1899;
        public int Motor { get; set; } = 0;
    }
}
