﻿namespace APIProject.Model
{
    public class Produs
    {
        public int Id { get; set; } = 0;
        public string Denumire { get; set; } = "";
        public int Stoc { get; set; } = 0;
        public double Pret { get; set; } = 1;
    }
}
